package com.example.launcheranim; // cambia al paquete de tu módulo

import android.animation.ValueAnimator;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.animation.Interpolator;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Animaciones estilo Samsung para el launcher (LSPosed).
 *
 *  - Apertura:            radio de esquina con curva t^p (mWindowRadius / cornerInterpolator).
 *  - Cierre con gesto:    sin escalón de 4 px + curva espejo (mLastCornerRadius / getCornerRadius).
 *  - Cierre botón/atrás:  radio ANIMADO (antes constante = val$windowCornerRadius), misma curva espejo.
 *  - Velocidad:           apertura y cierre x SPEED (1.5 = 50% más lentas), también el resorte del gesto.
 */
public class AnimHook implements IXposedHookLoadPackage {

    // ───────────── AJUSTES ─────────────
    // Curva del radio. 1.0 = lineal. Entre 1.6 y 2.6 se acerca al look Samsung.
    static final float CORNER_POW = 2.0f;

    // Factor de lentitud: 1.5 = x1.5 más lento y suave. 1.0 = como antes.
    static final float SPEED = 1.5f;

    // Duraciones base (ms) que ya usabas, multiplicadas por SPEED. Pon 0 para no tocarlas.
    static final long APP_LAUNCH_MS = Math.round(400 * SPEED);       // 600
    static final int CLOSE_MS = (int) Math.round(300 * SPEED);       // 450

    // Ralentizar también el resorte del cierre con gesto (RectFSpringAnim).
    static final boolean SLOW_GESTURE_SPRING = true;
    // ───────────────────────────────────

    static final String QTM = "com.android.launcher3.QuickstepTransitionManager";
    static final String MVUL = "com.android.quickstep.util.MultiValueUpdateListener";
    static final String SPRING = "com.android.quickstep.util.RectFSpringAnim";
    static final String SPRING_FORCE = "androidx.dynamicanimation.animation.SpringForce";

    static float clamp01(float t) {
        return t < 0f ? 0f : (t > 1f ? 1f : t);
    }

    // Apertura: el radio cambia tarde (t^p) y no de golpe al inicio.
    static final Interpolator OPEN_CURVE = new Interpolator() {
        @Override
        public float getInterpolation(float t) {
            return (float) Math.pow(clamp01(t), CORNER_POW);
        }
    };

    // Cierre: espejo temporal de la apertura.
    static float closeProgress(float f) {
        return 1f - (float) Math.pow(1f - clamp01(f), CORNER_POW);
    }

    private final Set<Object> patched =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<Object, Boolean>()));
    private final Set<Class<?>> hookedRunners =
            Collections.newSetFromMap(new ConcurrentHashMap<Class<?>, Boolean>());
    private final ConcurrentHashMap<Class<?>, Boolean> closeListenerCache = new ConcurrentHashMap<>();

    private static final ThreadLocal<Boolean> IN_SPRING = new ThreadLocal<>();

    // ── Estado del cierre con botón/atrás ──
    private static volatile long sBtnTs = 0;          // último fotograma visto del listener de cierre
    private static volatile float sBtnProg = 0f;      // progreso real (getAnimatedFraction)
    private static volatile long sBtnUntil = 0;       // ventana de respaldo si no vemos el listener
    private static volatile long sGestureTs = 0;      // último fotograma del cierre con gesto
    private static long sSessionStart = 0, sLastCall = 0;
    private static float sR0 = 0f;
    private static volatile float sScale = 1f, sCropW = 0f, sCropH = 0f;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        ClassLoader cl = lpp.classLoader;
        Class<?> qtm = XposedHelpers.findClassIfExists(QTM, cl);
        if (qtm == null) return; // este paquete no es el launcher

        XposedBridge.log("[AnimHook] activo en " + lpp.packageName
                + " | POW=" + CORNER_POW + " SPEED=" + SPEED);
        hookDurations(qtm);
        hookWindowAnimatorEntryPoints(qtm);
        hookOpenRadius(cl);
        hookSpringClose(cl);
        if (SLOW_GESTURE_SPRING) hookSpringSpeed(cl);
        hookButtonCloseRadius();
    }

    // ── Duraciones (apertura y cierre con botón/atrás) ─────────
    private void hookDurations(Class<?> qtm) {
        XposedBridge.hookAllConstructors(qtm, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    if (APP_LAUNCH_MS > 0)
                        XposedHelpers.setLongField(p.thisObject, "mAppLaunchDuration", APP_LAUNCH_MS);
                    if (CLOSE_MS > 0)
                        XposedHelpers.setIntField(p.thisObject, "mClosingTransitionDurationMs", CLOSE_MS);
                } catch (Throwable t) {
                    XposedBridge.log(t);
                }
            }
        });
    }

    // ── Respaldo: ventana de "cierre con botón/atrás" desde el manager ──
    private void hookWindowAnimatorEntryPoints(Class<?> qtm) {
        Set<XC_MethodHook.Unhook> close = XposedBridge.hookAllMethods(qtm, "getClosingWindowAnimators",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        sBtnUntil = SystemClock.uptimeMillis() + CLOSE_MS + 1000;
                        sSessionStart = 0;
                    }
                });
        Set<XC_MethodHook.Unhook> open = XposedBridge.hookAllMethods(qtm, "getOpeningWindowAnimators",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        sBtnUntil = 0;
                        sBtnTs = 0;
                        sSessionStart = 0;
                    }
                });
        if (close.isEmpty())
            XposedBridge.log("[AnimHook] sin getClosingWindowAnimators (uso solo el listener de cierre)");
        if (open.isEmpty())
            XposedBridge.log("[AnimHook] sin getOpeningWindowAnimators");
    }

    // ── Apertura: curva del radio + detección del listener de cierre ──
    private void hookOpenRadius(ClassLoader cl) {
        Class<?> mvul = XposedHelpers.findClassIfExists(MVUL, cl);
        if (mvul == null) {
            XposedBridge.log("[AnimHook] no encontré " + MVUL);
            return;
        }
        Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(mvul, "onAnimationUpdate",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        Object o = p.thisObject;
                        if (!o.getClass().getName().startsWith(QTM)) return;

                        trackButtonClose(o, p);

                        if (!patched.add(o)) return; // una sola vez por animación

                        // FloatProp.mInterpolator es private final: setObjectField lo permite.
                        try {
                            Object prop = XposedHelpers.getObjectField(o, "mWindowRadius");
                            if (prop != null)
                                XposedHelpers.setObjectField(prop, "mInterpolator", OPEN_CURVE);
                        } catch (Throwable ignored) { }

                        try {
                            XposedHelpers.setObjectField(o, "cornerInterpolator", OPEN_CURVE);
                        } catch (Throwable ignored) { }
                    }
                });
        if (hooks.isEmpty())
            XposedBridge.log("[AnimHook] no encontré onAnimationUpdate en " + MVUL);
    }

    /** Detecta el listener del cierre con botón/atrás (tiene val$windowCornerRadius y no mWindowRadius). */
    private void trackButtonClose(Object listener, XC_MethodHook.MethodHookParam p) {
        Class<?> c = listener.getClass();
        Boolean isClose = closeListenerCache.get(c);
        if (isClose == null) {
            isClose = XposedHelpers.findFieldIfExists(c, "val$windowCornerRadius") != null
                    && XposedHelpers.findFieldIfExists(c, "mWindowRadius") == null;
            closeListenerCache.put(c, isClose);
            if (isClose) XposedBridge.log("[AnimHook] listener de cierre botón/atrás: " + c.getName());
        }
        if (!isClose) return;
        sBtnTs = SystemClock.uptimeMillis();
        if (p.args.length > 0 && p.args[0] instanceof ValueAnimator)
            sBtnProg = ((ValueAnimator) p.args[0]).getAnimatedFraction();
    }

    // ── Cierre con gesto (resorte): sin saltos de 4 px + curva nueva ──
    private void hookSpringClose(ClassLoader cl) {
        Class<?> spring = XposedHelpers.findClassIfExists(SPRING, cl);
        if (spring == null) {
            XposedBridge.log("[AnimHook] no encontré " + SPRING);
            return;
        }
        Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(spring, "addOnUpdateListener",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        for (Object a : p.args) {
                            if (a == null) continue;
                            Class<?> c = a.getClass();
                            if (!c.getName().startsWith(QTM)) continue;
                            if (!hookedRunners.add(c)) continue;
                            hookRunner(c);
                        }
                    }
                });
        if (hooks.isEmpty())
            XposedBridge.log("[AnimHook] no encontré addOnUpdateListener en " + SPRING);
    }

    private void hookRunner(Class<?> c) {
        try {
            // Solo la clase que tiene el radio con escalón de 4 px
            XposedHelpers.findField(c, "mLastCornerRadius");

            // 1) Antes de cada fotograma, "olvida" el último radio para que
            //    abs(mLastCornerRadius - cornerRadius) >= 4 siempre se cumpla.
            XposedHelpers.findAndHookMethod(c, "onUpdate", RectF.class, float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            sGestureTs = SystemClock.uptimeMillis();
                            XposedHelpers.setFloatField(p.thisObject, "mLastCornerRadius", -1e9f);
                        }
                    });

            // 2) Sustituye CORNER_LEAD_INTERPOLATOR por la curva ajustable.
            XposedHelpers.findAndHookMethod(c, "getCornerRadius", float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            float f = (Float) p.args[0];
                            float s = XposedHelpers.getFloatField(p.thisObject, "mStartRadius");
                            float e = XposedHelpers.getFloatField(p.thisObject, "mEndRadius");
                            p.setResult(s + closeProgress(f) * (e - s));
                        }
                    });

            XposedBridge.log("[AnimHook] cierre por gesto enganchado en " + c.getName());
        } catch (Throwable t) {
            // No era la clase buscada (o cambió el nombre de algún método)
        }
    }

    // ── Velocidad del resorte del cierre con gesto ─────────────
    private void hookSpringSpeed(ClassLoader cl) {
        Class<?> spring = XposedHelpers.findClassIfExists(SPRING, cl);
        Class<?> force = XposedHelpers.findClassIfExists(SPRING_FORCE, cl);
        if (spring == null || force == null) {
            XposedBridge.log("[AnimHook] sin RectFSpringAnim/SpringForce: el resorte del gesto no se ralentiza");
            return;
        }
        // La duración de un resorte escala con 1/sqrt(rigidez): rigidez / SPEED² => tiempo x SPEED.
        XposedBridge.hookAllMethods(force, "setStiffness", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (!Boolean.TRUE.equals(IN_SPRING.get())) return;
                if (p.args.length == 1 && p.args[0] instanceof Float)
                    p.args[0] = ((Float) p.args[0]) / (SPEED * SPEED);
            }
        });
        XC_MethodHook flag = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) { IN_SPRING.set(true); }

            @Override
            protected void afterHookedMethod(MethodHookParam p) { IN_SPRING.remove(); }
        };
        XposedBridge.hookAllConstructors(spring, flag);
        XposedBridge.hookAllMethods(spring, "start", flag);
    }

    // ── Cierre con botón/atrás: radio animado en la superficie ──
    // El código original aplica un radio constante. Aquí se intercepta
    // SurfaceControl.Transaction.setCornerRadius mientras dura ese cierre y se
    // reemplaza por: radio visible R0 -> pastilla/círculo con la curva espejo.
    private void hookButtonCloseRadius() {
        Class<?> tx = XposedHelpers.findClassIfExists("android.view.SurfaceControl$Transaction", null);
        if (tx == null) {
            XposedBridge.log("[AnimHook] no encontré SurfaceControl.Transaction");
            return;
        }

        XposedBridge.hookAllMethods(tx, "setMatrix", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    if (p.args.length >= 2 && p.args[1] instanceof Matrix) {
                        float[] v = new float[9];
                        ((Matrix) p.args[1]).getValues(v);
                        float s = (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
                        if (s > 0.01f) sScale = s;
                    } else if (p.args.length == 5 && p.args[1] instanceof Float) {
                        float s = (float) Math.hypot((Float) p.args[1], (Float) p.args[2]);
                        if (s > 0.01f) sScale = s;
                    }
                } catch (Throwable ignored) { }
            }
        });

        XC_MethodHook crop = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    if (p.args.length >= 2 && p.args[1] instanceof Rect) {
                        Rect r = (Rect) p.args[1];
                        sCropW = r.width();
                        sCropH = r.height();
                    } else if (p.args.length >= 2 && p.args[1] instanceof RectF) {
                        RectF r = (RectF) p.args[1];
                        sCropW = r.width();
                        sCropH = r.height();
                    } else if (p.args.length == 3 && p.args[1] instanceof Integer) {
                        sCropW = (Integer) p.args[1];
                        sCropH = (Integer) p.args[2];
                    }
                } catch (Throwable ignored) { }
            }
        };
        XposedBridge.hookAllMethods(tx, "setWindowCrop", crop);
        XposedBridge.hookAllMethods(tx, "setCrop", crop);

        XposedBridge.hookAllMethods(tx, "setCornerRadius", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    if (p.args.length != 2 || !(p.args[1] instanceof Float)) return;
                    float v = buttonCloseRadius((Float) p.args[1]);
                    if (v >= 0f) p.args[1] = v;
                } catch (Throwable ignored) { }
            }
        });
    }

    /** Radio local a aplicar durante el cierre con botón/atrás, o -1 si no hay cierre activo. */
    private static float buttonCloseRadius(float original) {
        long now = SystemClock.uptimeMillis();

        // El cierre con gesto ya lo resuelve hookRunner: no tocarlo aquí.
        if (now - sGestureTs < 80) { sSessionStart = 0; return -1f; }

        boolean strong = (now - sBtnTs) < 80;   // vemos el listener real: progreso exacto
        boolean weak = now < sBtnUntil;         // respaldo: progreso por tiempo
        if (!strong && !weak) { sSessionStart = 0; return -1f; }
        if (sCropW <= 0f || sCropH <= 0f) return -1f;

        if (sSessionStart == 0 || (now - sLastCall) > 250) {
            sSessionStart = now;
            sR0 = original * Math.max(sScale, 0.05f); // radio visible inicial
        }
        sLastCall = now;

        float p;
        if (strong) {
            p = sBtnProg;
        } else {
            long el = now - sSessionStart;
            if (el > CLOSE_MS + 150L) return -1f;
            p = el / (float) CLOSE_MS;
        }

        float s = Math.max(sScale, 0.05f);
        float pill = Math.min(sCropW * s, sCropH * s) / 2f;     // radio que deja pastilla/círculo
        float vis = sR0 + (pill - sR0) * closeProgress(p);      // curva espejo
        vis = Math.max(0f, Math.min(vis, pill));
        return vis / s; // el radio se aplica antes de la matriz de escala
    }
}
